<?php

echo "Hello from PhP_fpm!\n";
